# 许可材料原文附件

本附件收集已有原文，不替代组件许可证，不宣称已满足全部再分发义务。

- npm/：按现有 930 项清单，在已安装包目录顶层找到的许可、版权、NOTICE 原文；不是对整个文件树的穷举。各文件保持原始字节。
- upstream/pi-v1.2.0/：Pi v1.2.0 固定提交的根 MIT 原文，补充两个直接 Pi 包本地缺少独立文本的问题。
- electron-runtime/：已安装 Electron 运行时的 LICENSE、LICENSES.chromium.html 及版本文件；文档附件的收录不表示现有 .app 已携带这些文件。
- sharp-native/：实际 @img/sharp-libvips-darwin-arm64 包的声明、版本和元数据，以及 v1.3.4 对应上游材料；内部组件版本表不代表完整源代码或全部版权通知。libnsgif 没有独立版本记录。
- tools/：评估构建时已收集的工具许可、版权及 NOTICE 原文；Ghostscript 相关文件仅作为历史评估证据保留，不代表当前随包目录仍含该二进制。
- license-texts/：SPDX 提供的 LGPL v3（包含所引 GPL v3）与 MPL 1.1 标准文本；通用文本不能替代各组件的版权通知或源码交付。
- npm-notice-coverage.csv：顶层原文收集范围；未发现顶层文件不等于未获许可，未安装也不等于无需审查。应根据最终实际分发内容确认。
- evidence.json：每份材料的来源、字节数和 SHA-256；review-summary.json 记录核验快照。

尚未补齐的分发义务以主说明《第三方来源与依赖说明》第六节为准。本附件不含测试素材、用户文件、密钥或模型权重。
